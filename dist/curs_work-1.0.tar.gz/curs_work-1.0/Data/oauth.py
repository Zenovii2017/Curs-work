def oauth():
    """
    data for authorization
    :return: dict
    """
    return {"authorization": "Basic TGplc2NZY1MyWVVvS0JqTTQ5anFDRU4yY2h6V01"
                             "0bDVKbXlmQkpZMzp5Vlp5TmhXNVBuNGN6aEJtV3N0Z291"
                             "U1JMSXNVdnZJR0o4emNFd2toUk9sWjZHbEkxQ0dQNVpUM"
                             "1NNSTJBeDVlQUx5RElCYTE5QmVQeGtQVUdqcmR2OFQ3RF"
                             "RINVFGVnNVenVrZ1NrSElaY0t2N2ZKSGFETGx4U1ltcUd"
                             "XN3JXQg==",
            "accept": "application/json, text/plain, */*"}

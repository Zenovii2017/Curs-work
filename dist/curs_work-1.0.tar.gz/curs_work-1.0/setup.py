from distutils.core import setup

setup(name="curs_work",
      version="1.0",
      py_modules=["Program"],
      packages=["checker", "Data", "file", "greetings", "URL"],
      scripts=[])
